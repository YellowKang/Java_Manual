#!/bin/bash
./start-server.sh
./start-kibana.sh
./start-logstash.sh
