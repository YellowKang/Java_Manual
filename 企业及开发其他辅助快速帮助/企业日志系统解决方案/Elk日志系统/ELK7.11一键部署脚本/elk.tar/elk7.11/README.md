# RocketMQ+监控一键部署



```
├── README.md																			# 概览文档
├── docker-compose-elasticsearch-server.yaml
├── docker-compose-kibana.yaml
├── docker-compose-logstash.yaml
├── es-conf
│   ├── elasticsearch.keystore
│   ├── elasticsearch.yml
│   ├── jvm.options
│   ├── log4j2.properties
│   ├── role_mapping.yml
│   ├── roles.yml
│   ├── users
│   └── users_roles
├── es-plugins 																		# 概览文档
├── kibana-conf
│   └── kibana.yml
├── logstash-conf
│   ├── conf.d
│   │   └── tcp-log.conf
│   └── logstash.yml
├── logstash-logs
├── start-all.sh
├── start-kibana.sh
├── start-logstash.sh
├── start-server.sh
├── uninstall-all.sh
├── uninstall-kibana.sh
├── uninstall-logstash.sh
└── uninstall-server.sh
```



```bash
├── README.md																	
├── broker-conf																
│   └── broker.conf														# Broker配置文件
├── docker-compose-rocketmq-broker.yaml				# 启动Broker的Compose文件
├── docker-compose-rocketmq-console.yaml			# 启动Console监控工具的Compose文件
├── docker-compose-rocketmq-namesrv.yaml			# 启动NameServer的Compose文件
├── start-all.sh															# 启动所有(NameSrv + Broker + Console)
├── start-broker.sh														# 单独启动Broker
├── start-console.sh													# 单独启动Console监控
├── start-namesrv.sh													# 单独启动NameServer
├── uninstall-all.sh													# 卸载所有（Console + Broker + NameSrv），并且删除文件
├── uninstall-broker.sh												# 卸载Broker删除文件
├── uninstall-console.sh											# 卸载Console
└── uninstall-namesrv.sh											# 卸载NameServer
```

# 启动前注意事项

​		注意修改Broker.conf中的配置文件IP地址

```sh
# broker集群名称
brokerClusterName=DefaultCluster
# brokerName节点名称多broker唯一
brokerName=broker-01
# brokerId 主节点为0
brokerId=0
# 宿主机IP，公网情况下填写公网IP,(Java连接NameSrv获取到的Broker地址)
brokerIP1=172.18.0.32
```

# 部署方式

​		首先查询是否创建Docker网络

```bash
docker network ls
```

​		没有则创建botpy网络，有则删除重定义IP地址或者修改Compose文件网络

```bash
docker network create --subnet=172.18.0.0/24 botpy
```

​		一键启动

```
sudo ./start-all.sh
```

# 服务信息



|        服务         |   虚拟IP    |                     端口号                      |      容器名      |      主机名      |
| :-----------------: | :---------: | :---------------------------------------------: | :--------------: | :--------------: |
| RocketMQ-NameServer | 172.18.0.31 |                    9876:9876                    | rocketmq-namesrv | rocketmq-namesrv |
|   RocketMQ-Broker   | 172.18.0.32 | 10911:10911<br />10912:10912<br />  10909:10909 | rocketmq-broker  | rocketmq-broker  |
|  RocketMQ-Console   | 172.18.0.33 |                    8180:8080                    | rocketmq-console | rocketmq-console |



# 一键卸载（注意会删除文件清空数据）

​		一键卸载

```
sudo ./uninstall-all.sh
```

