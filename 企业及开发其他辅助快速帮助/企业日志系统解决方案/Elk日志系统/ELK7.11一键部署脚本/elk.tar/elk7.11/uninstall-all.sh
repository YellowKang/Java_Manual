#!/bin/bash
./uninstall-server.sh
./uninstall-kibana.sh
./uninstall-logstash.sh
